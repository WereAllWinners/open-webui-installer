## Installation Instructions
1. Extract the contents of this package to a desired location.
2. Ensure WSL is installed and configured on your machine.
3. Place the `open-webui` executable in the appropriate directory (`/home/username/.local/bin`).
4. Run the `setup.ps1` script to create a shortcut on your desktop.
5. Use the desktop shortcut to start the application.
