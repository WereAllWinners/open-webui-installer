# Create necessary directories in WSL
wsl mkdir -p /home/$(wsl whoami)/.local/bin

# Copy the open-webui executable to WSL directory
copy-item -Path "$PSScriptRoot\open-webui" -Destination "$(wsl echo ~)/.local/bin/open-webui"

# Create a shortcut on the desktop
$desktop = [System.IO.Path]::Combine([System.Environment]::GetFolderPath("Desktop"), "Open Web UI.lnk")
$ws = New-Object -ComObject WScript.Shell
$shortcut = $ws.CreateShortcut($desktop)
$shortcut.TargetPath = "$PSScriptRoot\open-webui.bat"
$shortcut.IconLocation = "$PSScriptRoot\icon.ico"
$shortcut.Save()

Write-Output "Setup complete. Shortcut created on the desktop."
